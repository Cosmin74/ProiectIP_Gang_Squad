﻿
namespace Logare
{
    partial class Inregistrare
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.last_name = new System.Windows.Forms.TextBox();
            this.first_name = new System.Windows.Forms.TextBox();
            this.mail_address = new System.Windows.Forms.TextBox();
            this.pass = new System.Windows.Forms.TextBox();
            this.weight = new System.Windows.Forms.TextBox();
            this.height = new System.Windows.Forms.TextBox();
            this.age = new System.Windows.Forms.TextBox();
            this.gen = new System.Windows.Forms.ComboBox();
            this.activity = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(66, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nume";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(495, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Prenume";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 159);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Adresa de email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(495, 159);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Parolă";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(47, 256);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Greutate";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(69, 426);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 53);
            this.button1.TabIndex = 10;
            this.button1.Text = "Inregistreaza";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(206, 426);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(111, 53);
            this.button2.TabIndex = 11;
            this.button2.Text = "Inapoi la logare";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(47, 209);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "Gen";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(441, 209);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 17);
            this.label7.TabIndex = 13;
            this.label7.Text = "Nivel de activitate";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(495, 256);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 17);
            this.label8.TabIndex = 14;
            this.label8.Text = "Înălțime";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(47, 313);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 17);
            this.label9.TabIndex = 15;
            this.label9.Text = "Vârstă";
            // 
            // last_name
            // 
            this.last_name.Location = new System.Drawing.Point(133, 113);
            this.last_name.Name = "last_name";
            this.last_name.Size = new System.Drawing.Size(184, 22);
            this.last_name.TabIndex = 16;
            // 
            // first_name
            // 
            this.first_name.Location = new System.Drawing.Point(593, 113);
            this.first_name.Name = "first_name";
            this.first_name.Size = new System.Drawing.Size(174, 22);
            this.first_name.TabIndex = 17;
            // 
            // mail_address
            // 
            this.mail_address.Location = new System.Drawing.Point(133, 159);
            this.mail_address.Name = "mail_address";
            this.mail_address.Size = new System.Drawing.Size(184, 22);
            this.mail_address.TabIndex = 18;
            // 
            // pass
            // 
            this.pass.Location = new System.Drawing.Point(593, 159);
            this.pass.Name = "pass";
            this.pass.PasswordChar = '*';
            this.pass.Size = new System.Drawing.Size(174, 22);
            this.pass.TabIndex = 19;
            // 
            // weight
            // 
            this.weight.Location = new System.Drawing.Point(133, 256);
            this.weight.Name = "weight";
            this.weight.Size = new System.Drawing.Size(184, 22);
            this.weight.TabIndex = 22;
            // 
            // height
            // 
            this.height.Location = new System.Drawing.Point(593, 253);
            this.height.Name = "height";
            this.height.Size = new System.Drawing.Size(174, 22);
            this.height.TabIndex = 23;
            // 
            // age
            // 
            this.age.Location = new System.Drawing.Point(133, 313);
            this.age.Name = "age";
            this.age.Size = new System.Drawing.Size(184, 22);
            this.age.TabIndex = 24;
            // 
            // gen
            // 
            this.gen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.gen.FormattingEnabled = true;
            this.gen.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.gen.Items.AddRange(new object[] {
            "Masculin",
            "Feminin"});
            this.gen.Location = new System.Drawing.Point(133, 209);
            this.gen.Name = "gen";
            this.gen.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gen.Size = new System.Drawing.Size(184, 24);
            this.gen.TabIndex = 25;
            this.gen.Tag = "";
            this.gen.SelectedIndexChanged += new System.EventHandler(this.gen_SelectedIndexChanged);
            // 
            // activity
            // 
            this.activity.AutoCompleteCustomSource.AddRange(new string[] {
            "Sedentary",
            "Light exercise",
            "Moderate exercise",
            "Active",
            "Very active",
            "Extra active"});
            this.activity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.activity.FormattingEnabled = true;
            this.activity.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.activity.Items.AddRange(new object[] {
            "Sedentary",
            "Light exercise",
            "Moderate exercise",
            "Active",
            "Very active",
            "Extra active"});
            this.activity.Location = new System.Drawing.Point(593, 206);
            this.activity.Name = "activity";
            this.activity.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.activity.Size = new System.Drawing.Size(174, 24);
            this.activity.TabIndex = 26;
            this.activity.Tag = "";
            // 
            // Inregistrare
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1027, 563);
            this.Controls.Add(this.activity);
            this.Controls.Add(this.gen);
            this.Controls.Add(this.age);
            this.Controls.Add(this.height);
            this.Controls.Add(this.weight);
            this.Controls.Add(this.pass);
            this.Controls.Add(this.mail_address);
            this.Controls.Add(this.first_name);
            this.Controls.Add(this.last_name);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Inregistrare";
            this.Text = "Inregistrare";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox last_name;
        private System.Windows.Forms.TextBox first_name;
        private System.Windows.Forms.TextBox mail_address;
        private System.Windows.Forms.TextBox pass;
        private System.Windows.Forms.TextBox weight;
        private System.Windows.Forms.TextBox height;
        private System.Windows.Forms.TextBox age;
        private System.Windows.Forms.ComboBox gen;
        private System.Windows.Forms.ComboBox activity;
    }
}