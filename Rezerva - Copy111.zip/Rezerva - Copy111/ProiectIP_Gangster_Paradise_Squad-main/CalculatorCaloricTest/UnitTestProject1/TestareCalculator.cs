﻿/**************************************************************************
 *                                                                        *
 *  File:        Calculator.cs                                            *
 *                                                                        *
 *  Descriere:Se afișează un grafic cu evoluția pe zile                   *
 *              a progresului utilizatorului                              *
 *                                                                        *
 *                                                                        *
 *                                                                        *
 *  Autor:  Aursulesei Cosmin-Irimia                                      *
 *                                                                        *
 *                                                                        *
 **************************************************************************/
using CalculatorCaloric;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestareCalculator
{
    [TestClass]
    public class TestareCalculator
    {
        [TestMethod]
        public void Test_Male_Sedentary()
        {
            Calculator calculator = new Calculator("Male", "Sedentary", 70, 180, 30);
            double expected = 2016;
            double result = calculator.MifflinStJeorEquation();
            Assert.AreEqual(expected, result,0.01);
        }

        [TestMethod]
        public void Test_Male_Light_Exercise()
        {
            Calculator calculator = new Calculator("Male", "Light exercise", 70, 280, 30);
            double expected = 3169.375;
            double result = calculator.MifflinStJeorEquation();
            Assert.AreEqual(expected, result, 0.01);
        }

        [TestMethod]
        public void Test_Male_Moderate_Exercise()
        {
            Calculator calculator = new Calculator("Male", "Moderate exercise", 70, 280, 30);
            double expected = 3376.825;
            double result = calculator.MifflinStJeorEquation();
            Assert.AreEqual(expected, result, 0.01);
        }

        [TestMethod]
        public void Test_Male_Active()
        {
            Calculator calculator = new Calculator("Male", "Active", 90, 230, 30);
            double expected = 3398.375;
            double result = calculator.MifflinStJeorEquation();
            Assert.AreEqual(expected, result, 0.01);
        }

        [TestMethod]
        public void Test_Male_Very_Active()
        {
            Calculator calculator = new Calculator("Male", "Very active", 90, 230, 30);
            double expected = 3782.0625;
            double result = calculator.MifflinStJeorEquation();
            Assert.AreEqual(expected, result, 0.01);
        }

        [TestMethod]
        public void Test_Male_Extra_Active()
        {
            Calculator calculator = new Calculator("Male", "Extra active", 90, 230, 30);
            double expected = 4165.75;
            double result = calculator.MifflinStJeorEquation();
            Assert.AreEqual(expected, result, 0.01);
        }

        [TestMethod]
        public void Test_Female_Sedentary()
        {
            Calculator calculator = new Calculator("Female", "Sedentary", 60, 195, 25);
            double expected = 1839.3;
            double result = calculator.MifflinStJeorEquation();
            Assert.AreEqual(expected, result, 0.01);
        }

        [TestMethod]
        public void Test_Female_Light_Exercise()
        {
            Calculator calculator = new Calculator("Female", "Light Exercise", 70, 195, 25);
            double expected = 1632.75;
            double result = calculator.MifflinStJeorEquation();
            Assert.AreEqual(expected, result, 0.01);
        }

        [TestMethod]
        public void Test_Female_ModerateExercise()
        {
            Calculator calculator = new Calculator("Female", "Moderate exercise", 60, 165, 25);
            double expected = 1970.79125;
            double result = calculator.MifflinStJeorEquation();
            Assert.AreEqual(expected, result, 0.01);
        }

        [TestMethod]
        public void Test_Female_Active()
        {
            Calculator calculator = new Calculator("Female", "Active", 60, 165, 45);
            double expected = 1930.1375;
            double result = calculator.MifflinStJeorEquation();
            Assert.AreEqual(expected, result, 0.01);
        }

        [TestMethod]
        public void Test_Female_Very_Active()
        {
            Calculator calculator = new Calculator("Female", "Very Active", 70, 165, 45);
            double expected = 1345.25;
            double result = calculator.MifflinStJeorEquation();
            Assert.AreEqual(expected, result, 0.01);
        }

        [TestMethod]
        public void Test_Female_Extra_Active()
        {
            Calculator calculator = new Calculator("Female", "Extra Active", 60, 205, 45);
            double expected = 1495.25;
            double result = calculator.MifflinStJeorEquation();
            Assert.AreEqual(expected, result, 0.01);
        }

        [TestMethod]
        public void Test_LoseWeightResults_Active()
        {
            Calculator calculator = new Calculator("Male", "Active", 80, 175, 35);
            string mentain = System.Environment.NewLine + " Menține greutatea: 2671.8125 kcal." + System.Environment.NewLine;
            string mild = System.Environment.NewLine + " Pierdere ușoară în greutate: 2421.8125 kcal." + System.Environment.NewLine;
            string lose = System.Environment.NewLine + " Pierdere în greutate: 2171.8125 kcal." + System.Environment.NewLine;
            string fast = System.Environment.NewLine + " Pierdere rapidă în greutate: 1671.8125 kcal." + System.Environment.NewLine;
            string info = System.Environment.NewLine + "  Rezultatele arată o serie de estimări zilnice de calorii care pot fi folosite ca ghid pentru câte calorii trebuie consumate în fiecare zi.";
            string expected = mentain + mild + lose + fast + info;
            string result = calculator.loseWeightResults();
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void Test_LoseWeightResults_Sedentary()
        {
            Calculator calculator = new Calculator("Female", "Sedentary", 90, 195, 35);
            string mentain = System.Environment.NewLine + " Menține greutatea: 2139.3 kcal." + System.Environment.NewLine;
            string mild = System.Environment.NewLine + " Pierdere ușoară în greutate: 1889.3 kcal." + System.Environment.NewLine;
            string lose = System.Environment.NewLine + " Pierdere în greutate: 1639.3 kcal." + System.Environment.NewLine;
            string fast = System.Environment.NewLine + " Pierdere rapidă în greutate: 1139.3 kcal." + System.Environment.NewLine;
            string info = System.Environment.NewLine + "  Rezultatele arată o serie de estimări zilnice de calorii care pot fi folosite ca ghid pentru câte calorii trebuie consumate în fiecare zi.";
            string expected = mentain + mild + lose + fast + info;
            string result = calculator.loseWeightResults();
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void Test_LoseWeightResults_Light_Exxercise()
        {
            Calculator calculator = new Calculator("Male", "Light exercise", 80, 175, 35);
            string mentain = System.Environment.NewLine + " Menține greutatea: 2370.15625 kcal." + System.Environment.NewLine;
            string mild = System.Environment.NewLine + " Pierdere ușoară în greutate: 2120.15625 kcal." + System.Environment.NewLine;
            string lose = System.Environment.NewLine + " Pierdere în greutate: 1870.15625 kcal." + System.Environment.NewLine;
            string fast = System.Environment.NewLine + " Pierdere rapidă în greutate: 1370.15625 kcal." + System.Environment.NewLine;
            string info = System.Environment.NewLine + "  Rezultatele arată o serie de estimări zilnice de calorii care pot fi folosite ca ghid pentru câte calorii trebuie consumate în fiecare zi.";
            string expected = mentain + mild + lose + fast + info;
            string result = calculator.loseWeightResults();
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void Test_LoseWeightResults_Light_Exxercise_Female()
        {
            Calculator calculator = new Calculator("Female", "Light exercise", 80, 195, 35);
            string mentain = System.Environment.NewLine + " Menține greutatea: 2313.78125 kcal." + System.Environment.NewLine;
            string mild = System.Environment.NewLine + " Pierdere ușoară în greutate: 2063.78125 kcal." + System.Environment.NewLine;
            string lose = System.Environment.NewLine + " Pierdere în greutate: 1813.78125 kcal." + System.Environment.NewLine;
            string fast = System.Environment.NewLine + " Pierdere rapidă în greutate: 1313.78125 kcal." + System.Environment.NewLine;
            string info = System.Environment.NewLine + "  Rezultatele arată o serie de estimări zilnice de calorii care pot fi folosite ca ghid pentru câte calorii trebuie consumate în fiecare zi.";
            string expected = mentain + mild + lose + fast + info;
            string result = calculator.loseWeightResults();
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void Test_GainWeightResults_Light()
        {
            Calculator calculator = new Calculator("Female", "Light exercise", 55, 160, 28);
            string mentain = System.Environment.NewLine + " Menține greutatea: 1717.375 kcal." + System.Environment.NewLine;
            string mild = System.Environment.NewLine + " Creștere ușoară în greutate: 1967.375 kcal." + System.Environment.NewLine;
            string gain = System.Environment.NewLine + " Creștere în greutate: 2217.375 kcal." + System.Environment.NewLine;
            string fast = System.Environment.NewLine + " Creștere rapidă în greutate: 2717.375 kcal." + System.Environment.NewLine;
            string info = System.Environment.NewLine + "  Rezultatele arată o serie de estimări zilnice de calorii care pot fi folosite ca ghid pentru câte calorii trebuie consumate în fiecare zi,";
            string expected = mentain + mild + gain + fast + info;
            string result = calculator.gainWeightResults();
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void Test_GainWeightResults_Extra()
        {
            Calculator calculator = new Calculator("Male", "Extra active", 55, 190, 67);
            string mentain = System.Environment.NewLine + " Menține greutatea: 2674.25 kcal." + System.Environment.NewLine;
            string mild = System.Environment.NewLine + " Creștere ușoară în greutate: 2924.25 kcal." + System.Environment.NewLine;
            string gain = System.Environment.NewLine + " Creștere în greutate: 3174.25 kcal." + System.Environment.NewLine;
            string fast = System.Environment.NewLine + " Creștere rapidă în greutate: 3674.25 kcal." + System.Environment.NewLine;
            string info = System.Environment.NewLine + "  Rezultatele arată o serie de estimări zilnice de calorii care pot fi folosite ca ghid pentru câte calorii trebuie consumate în fiecare zi,";
            string expected = mentain + mild + gain + fast + info;
            string result = calculator.gainWeightResults();
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void Test_GainWeightResults_Sedentary()
        {
            Calculator calculator = new Calculator("Male", "Sedentary", 75, 290, 77);
            string mentain = System.Environment.NewLine + " Menține greutatea: 2619 kcal." + System.Environment.NewLine;
            string mild = System.Environment.NewLine + " Creștere ușoară în greutate: 2869 kcal." + System.Environment.NewLine;
            string gain = System.Environment.NewLine + " Creștere în greutate: 3119 kcal." + System.Environment.NewLine;
            string fast = System.Environment.NewLine + " Creștere rapidă în greutate: 3619 kcal." + System.Environment.NewLine;
            string info = System.Environment.NewLine + "  Rezultatele arată o serie de estimări zilnice de calorii care pot fi folosite ca ghid pentru câte calorii trebuie consumate în fiecare zi,";
            string expected = mentain + mild + gain + fast + info;
            string result = calculator.gainWeightResults();
            Assert.AreEqual(expected, result);
        }

    }
}
