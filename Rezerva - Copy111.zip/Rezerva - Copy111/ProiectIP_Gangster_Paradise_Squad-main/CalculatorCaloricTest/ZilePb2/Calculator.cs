﻿/**************************************************************************
 *                                                                        *
 *  File:        Calculator.cs                                            *
 *                                                                        *
 *  Descriere:Se afișează un grafic cu evoluția pe zile                   *
 *              a progresului utilizatorului                              *
 *                                                                        *
 *                                                                        *
 *                                                                        *
 *  Autor:    Aursulesei Cosmin-Irimia                                    *
 *                                                                        *
 *                                                                        *
 **************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorCaloric
{
    public class Calculator
    {

        /// <summary>
        /// Datele clientului necesare pentru calcularea necesarului
        /// </summary>
        private string _gender;
        private string _activityLevel;
        private double _weight;
        private double _height;
        private int _age;

        public Calculator(string gender, string activityLevel, double weight, double height, int age)
        {
            _gender = gender;
            _activityLevel = activityLevel;
            _weight = weight;
            _height = height;
            _age = age;
        }

        /// <summary>
        /// Calculează rata metabolică în funcție de nivelul zilnic de activitate
        /// </summary>
        public double MifflinStJeorEquation()
        {
            double activityFactor;
            switch (_activityLevel)
            {
                case "Sedentary":
                    activityFactor = 1.2;
                    break;
                case "Light exercise":
                    activityFactor = 1.375;
                    break;
                case "Moderate exercise":
                    activityFactor = 1.465;
                    break;
                case "Active":
                    activityFactor = 1.55;
                    break;
                case "Very active":
                    activityFactor = 1.725;
                    break;
                case "Extra active":
                    activityFactor = 1.9;
                    break;
                default:
                    activityFactor = 1;
                    break;
            }

            if (_gender == "Male")
            {
                return (10 * _weight + 6.25 * _height - 5 * _age + 5) * activityFactor;
            }
            else
            {
                return (10 * _weight + 6.25 * _height - 5 * _age - 161) * activityFactor;
            }
        }

        /// <summary>
        /// Afișare multiple opțiuni pentru pierderea în gerutate
        /// </summary>
        public string loseWeightResults()
        {
            double maintainWeight = MifflinStJeorEquation();
            string mentain = System.Environment.NewLine + " Menține greutatea: " + maintainWeight + " kcal." + System.Environment.NewLine;
            string mild = System.Environment.NewLine + " Pierdere ușoară în greutate: " + (maintainWeight - 250) + " kcal." + System.Environment.NewLine;
            string lose = System.Environment.NewLine + " Pierdere în greutate: " + (maintainWeight - 500) + " kcal." + System.Environment.NewLine;
            string fast = System.Environment.NewLine + " Pierdere rapidă în greutate: " + (maintainWeight - 1000) + " kcal." + System.Environment.NewLine;
            string info = System.Environment.NewLine + "  Rezultatele arată o serie de estimări zilnice de calorii care pot fi folosite ca ghid pentru câte calorii trebuie consumate în fiecare zi.";
            string results = mentain + mild + lose + fast + info;
            return results;
        }

        /// <summary>
        /// Afișare multiple opțiuni pentru creștere în gerutate
        /// </summary>
        public string gainWeightResults()
        {
            double maintainWeight = MifflinStJeorEquation();
            string mentain = System.Environment.NewLine + " Menține greutatea: " + maintainWeight + " kcal." + System.Environment.NewLine;
            string mild = System.Environment.NewLine + " Creștere ușoară în greutate: " + (maintainWeight + 250) + " kcal." + System.Environment.NewLine;
            string gain = System.Environment.NewLine + " Creștere în greutate: " + (maintainWeight + 500) + " kcal." + System.Environment.NewLine;
            string fast = System.Environment.NewLine + " Creștere rapidă în greutate: " + (maintainWeight + 1000) + " kcal." + System.Environment.NewLine;
            string info = System.Environment.NewLine + "  Rezultatele arată o serie de estimări zilnice de calorii care pot fi folosite ca ghid pentru câte calorii trebuie consumate în fiecare zi,";
            string results = mentain + mild + gain + fast + info;
            return results;
        }
    }

}
